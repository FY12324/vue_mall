module.exports = {
  publicPath: './',
  productionSourceMap: false,
  lintOnSave: true
}