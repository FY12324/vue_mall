<template>
  <div class="home">
    <div class="denglu">
    <router-link to='/Login'>登录</router-link>
    <router-link to='/Register'>注册</router-link>
    </div>
  </div>
</template>
<script>


  export default {
    name: 'home',
    data() {
      return {
        backImg:[
   
        ], //轮播图照片数组
        navImg:[],   // 导航分类
        loucengImg:[] //楼层
      }
    },
    mounted() {
            
    },
    components: {
          // Search
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>