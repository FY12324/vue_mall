<template>
  <div class="home">
   
  </div>
</template>
<script>

  export default {
    name: 'home',
    data() {
      return {
        // 获取轮播图数据
       let promise1= this.axios.get('/home/swiperdata')
       promise1.then((res)=>{
        //    console.log(res)
           this.backImg=res.data.message
       })
        //  请求分类
        let promise2=this.axios.get('/home/catitems')
        promise2.then((res)=>{
            // console.log(res)
            this.navImg=res.data.message
        })
        // 请求楼层数据
        let promise3=this.axios.get('/home/floordata')
        promise3.then((res)=>{
            // console.log(res)
            this.loucengImg=res.data.message
        })   
      }
    },
    mounted() {
    
    },
    components: {
     
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>