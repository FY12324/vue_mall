<template>
  <div class="home">
    <router-link to='/Login'>登录</router-link>
    <router-link to='/Register'>注册</router-link>
    <div class="lunboArea">
      <mt-swipe :auto="4000">
        <mt-swipe-item v-for="item in backImg.img" :key="item.goods_id">
          <img class="lunboPic" :src="item" />
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <!--导航区域 -->
    <div class="navArea">
      <div class="navItem" v-for="item in navImg.img" :key="item.name">
        <img :src="item.image_src" />
      </div>
    </div>
    <!-- 楼层区域 -->
    <div class="loucengArea">
      <div class="loucengItem clearFix" v-for="item in loucengImg" :key="item.index">
        <div class="title">
          <img class="titleImg" :src="item.floor_title.image_src" alt="">
        </div>
        <div class="product" v-for="product in item.goodList" :key="index">
          <img class="productImg" :src="product.image_src" alt="">
        </div>
      </div>
    </div>
  </div>
</template>
<script>


  export default {
    name: 'home',
    data() {
      return {
        backImg:[
   
        ], //轮播图照片数组
        navImg:[],   // 导航分类
        loucengImg:[] //楼层
      }
    },
    mounted() {
            
    },
    components: {
          // Search
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>