<template>
  <div class="home">
   <Search></Search>
   <div class="lunboArea">
          <el-carousel :interval="5000" arrow="always"  height="150px">
            <el-carousel-item v-for="item in backImg" :key="item.goods_id">
                <img class="lunboPic" :src="item.image_src" />
            </el-carousel-item>
            </el-carousel>
        </div>
  </div>
</template>
<script>

  export default {
    name: 'home',
    data() {
      return {
  
      }
    },
    mounted() {
            // 获取轮播图数据
            let promise1= this.axios.get('/home/swiperdata')
       promise1.then((res)=>{
        //    console.log(res)
           this.backImg=res.data.message
       })
        //  请求分类
        let promise2=this.axios.get('/home/catitems')
        promise2.then((res)=>{
            // console.log(res)
            this.navImg=res.data.message
        })
        // 请求楼层数据
        let promise3=this.axios.get('/home/floordata')
        promise3.then((res)=>{
            // console.log(res)
            this.loucengImg=res.data.message
        }) 
    },
    components: {
     
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>