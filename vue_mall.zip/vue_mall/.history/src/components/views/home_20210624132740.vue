<template>
  <div class="home">
   
  </div>
</template>
<script>

  export default {
    name: 'home',
    data() {
      return {
        
      }
    },
    mounted() {
    
    },
    components: {
     
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>