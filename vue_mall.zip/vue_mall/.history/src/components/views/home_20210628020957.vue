<template>
  <div class="home">
   <Search></Search>
   <div class="lunboArea">
    <mt-swipe :auto="4000">
      <mt-swipe-item v-for="item in backImg" :key="item.goods_id">
          <img class="lunboPic" :src="item.image_src" />
      </mt-swipe-item>
      </el-carousel>
  </div>
        <!--导航区域 -->
        <div class="navArea">
            <div class="navItem" v-for="item in navImg" :key="item.name">
                <img  :src="item.image_src" />
            </div>
        </div>
        <!-- 楼层区域 -->
        <div class="loucengArea">
          <div class="loucengItem clearFix" v-for="item in loucengImg" :key="item.index">
            <div class="title">
              <img class="titleImg" :src="item.floor_title.image_src" alt="">
            </div>
          <div class="product" v-for="product in item.goodList" :key="index">
            <img class="productImg" :src="product.image_src" alt="">
          </div>
  </div>
</div>

<mt-swipe :auto="4000">
  <mt-swipe-item v-for="(item,index) in goodsDetail.img" :key="index"><img :src="item" /></mt-swipe-item>
</mt-swipe>
  </div>
</template>
<script>
import Search from '../common/Search'
  export default {
    name: 'home',
    data() {
      return {
        backImg:[
          {img:'../../assets/img/banner_1.jpg'},
          {img:'../../assets/img/banner_2.jpg'},
          {img:'../../assets/img/banner_3.jpg'},
          {img:'../../assets/img/banner_4.jpg'},
          {img:'../../assets/img/banner_5.jpg'},
        ], //轮播图照片数组
        navImg:[],   // 导航分类
        loucengImg:[] //楼层
      }
    },
    mounted() {
            // 获取轮播图数据
            let promise1= this.axios.get('/home/swiperdata')
       promise1.then((res)=>{
        //    console.log(res)
           this.backImg=res.data.message
       })
        //  请求分类
        let promise2=this.axios.get('/home/catitems')
        promise2.then((res)=>{
            // console.log(res)
            this.navImg=res.data.message
        })
        // 请求楼层数据
        let promise3=this.axios.get('/home/floordata')
        promise3.then((res)=>{
            // console.log(res)
            this.loucengImg=res.data.message
        }) 
    },
    components: {
          Search
    },
    methods: {
      
    }
  }
</script>
<style lang="scss" scoped>
  
</style>