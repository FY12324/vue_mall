<template>
    <diiv class="enterUp">
        <transition appear appear-active-class="animated swing">
            <input placeholder="请输入账号"/>
            <input placeholder="请输入密码"/>
            <button>登录</button>
            <button>注册</button>
        </transition>
    </diiv>
</template>

<script>
    export default{
        data(){
            show:'true'
        }
    }
</script>