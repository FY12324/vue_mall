<template>
    <div class="searchArea">
        <input type="text" placeholder="请输入商品名称">
        <button>搜索</button>
    </div>
</template>
