<template>
    <div>
        <input placeholder="请输入您的手机号码"/>
        <input placeholder="请输入您收到的验证码"/>
        <input placeholder="设置您的密码"/>
        <button @click="">注册</button>
    </div>
</template>
