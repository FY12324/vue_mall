<template>
        <transition name="fade" mode="out-in">
            <div v-if="true">
                <input placeholder="请输入账号"/><br/>
                <input placeholder="请输入密码"/><br/>
                <button>登录</button>
            </div>
        </transition>
</template>

<script>
    export default{
        // data(){
        //     show:'true'
        // }
    }
</script>
<style lang="scss" scoped>
    
</style>