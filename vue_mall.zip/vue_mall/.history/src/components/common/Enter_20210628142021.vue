<template>
    <diiv class="enterUp">
        <transition appear appear-active-class="animated swing">
            enter-active-class="animated bounceIn"
            leave-active-class="animated bounceOut"
            <div v-if="show">
                <input placeholder="请输入账号"/>
                <input placeholder="请输入密码"/>
                <button>登录</button>
                <button>注册</button>
            </div>
        </transition>
    </diiv>
</template>

<script>
    export default{
        data(){
            show:'true'
        }
    }
</script>