<template>
    <transition name="fade" mode="out-in">
        <div v-if="true">
        <input placeholder="请输入您的手机号码"/><br/>
        <input placeholder="请输入您收到的验证码"/><br/>
        <input placeholder="设置您的密码"/><br/>
        <button @click="">注册</button>
    </div>
</template>

<script>
    export default{
        
    }
</script>
