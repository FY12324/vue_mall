<template>
    <diiv class="enterUp">
        <input placeholder="请输入账号"/>
        <input placeholder="请输入密码"/>
    </diiv>
</template>