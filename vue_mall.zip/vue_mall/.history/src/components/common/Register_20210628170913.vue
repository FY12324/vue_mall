<template>
    <transition apper apper-active-class="animated flash"
        <div v-if="true">
        <input placeholder="请输入您的手机号码"/><br/>
        <input placeholder="请输入您收到的验证码"/><br/>
        <input placeholder="设置您的密码"/><br/>
        <button @click="">注册</button>
    </div>
</transition>
</template>

<script>
    export default{
        
    }
</script>
<style lang="scss" scoped>
    .fade-enter,.fade-leave-to{
        opacity: 0;
    }
    .fade-enter-active,.fade-leave-active{
        transition: opacity .5s;
    }
</style>