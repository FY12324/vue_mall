<template>
    <diiv class="enterUp">
        <input placeholder="请输入账号"/>
        <input placeholder="请输入密码"/>
        <button>登录</button>
        <button>注册</button>
    </diiv>
</template>

<script>
    export default{
        data(){
            show:'true'
        }
    }
</script>